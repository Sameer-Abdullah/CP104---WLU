"""
-------------------------------------------------------
Midterm B Task 4 Testing
-------------------------------------------------------
Author: Sameer Abdullah
ID:     169065039
Email:  abdu5039@mylaurier.ca
__updated__ = "2023-11-01"
-------------------------------------------------------
"""
# Imports
# your imports here
from t04_functions import get_it

# your code here
response = input("Enter (Y/N)? ")
classification = get_it(response)

print(classification)
