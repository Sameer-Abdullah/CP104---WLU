"""
-------------------------------------------------------
Midterm B Task 3 Function Definitions
-------------------------------------------------------
Author: Sameer Abdullah
ID:     169065039
Email:  abdu5039@mylaurier.ca
__updated__ = "2023-11-01"
-------------------------------------------------------
"""
# Constants
COST = 125.00
EXTRA_SERVICE_COST = 25.00
VIP_DISCOUNT = 0.1
# your constants here


def servicing():
    """
    -------------------------------------------------------
    Determines the cost of getting a home furnace tune up. The cost is made up of:
        base cost: $125.00
        cost per extra service: $25.00
        VIP discount 10% only if:
            more than 1 extra service purchased
            and purchaser is a VIP
    The function must ask the user for these inputs.
    Use: cost = servicing()
    -------------------------------------------------------
    Returns‌​‌​​​​‌​​‌‌‌​‌‌‌​‌​​‌​​‌‌‌‌:
        cost - cost of getting a home furnace tune up based upon the base cost,
            the number of extra services purchased, and VIP discount
            if applicable (float)
    -------------------------------------------------------
    """
    extra_service = int(input("Are you purchasing any extra services: "))
    vip_member = input("Are you a VIP member (Y/N)? ")

    cost = COST + EXTRA_SERVICE_COST

    if extra_service > 1 and vip_member == "Y":
        cost -= cost * VIP_DISCOUNT
    elif extra_service > 1 and (vip_member == "N" or vip_member == "n"):
        cost = COST + (EXTRA_SERVICE_COST * extra_service)
    else:
        print("ERROR")
    return cost
    # your code here

    return
