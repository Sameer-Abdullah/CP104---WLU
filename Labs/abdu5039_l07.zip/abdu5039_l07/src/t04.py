"""
-------------------------------------------------------
[This program calculates the sum of square to, and greater
then or equal to, a target value.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-02"
-------------------------------------------------------
"""
# Imports
from functions import sum_squares

# Input for a target value
target = int(input("Enter a target value: "))

# calls on the function sum_squares
final = sum_squares(target)

# Output
print(final)
