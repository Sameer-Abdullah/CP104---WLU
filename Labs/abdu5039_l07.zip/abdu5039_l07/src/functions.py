"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-02"
-------------------------------------------------------
"""
# Imports
from random import randint


def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    ---------------------------------------------------------
    """
    # Random number from 1 to high
    number = randint(1, high)

    # Constants
    count = 0
    check = True

    # While loop
    while check == True:
        # Asks for input for guess
        guess = int(input("Guess: "))
        # keeps count of the number of guesses
        count += 1
        # if statment to check if the number is too low or high
        if guess < number:
            print("Too low, try again.")
        elif guess > number:
            print("Too high, try again. ")
        # if the uses guesses it correct then the message will play
        else:
            print("Congratulations - good guess!")
            # gets out of the while loop
            check = False
            print(f"You made {count} guesses.")

    return count


def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    # Constants
    power = 1

    # Calculates the nearest power of 2
    while power < target:
        power *= 2

    return power


def population_growth(target, current, rate):
    """
    -------------------------------------------------------
    Determines the number of years to reach a target population.
    Use: years = population_growth(target, current, rate)
    -------------------------------------------------------
    Parameters:
        target - target population (int > current)
        current - current population (int > 1)
        rate - percent rate of growth (float > 0)
    Returns:
        years - the number of years to reach target population (int)
    -------------------------------------------------------
    """
    years = 0

    while current < target:
        current += int(current * (rate / 100))
        years += 1

    return years


def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """
    # constants
    current = 1
    final = 0

    # Calculate the sum of squares
    while final <= target:
        final += current ** 2
        current += 1

    return final


def meal_costs():
    """
    -------------------------------------------------------
    Asks a user the costs of breakfast, lunch, and supper for each
    day the user was away. Assumes there is at least one day, and
    after entering data for each day asks the user whether they want
    to enter data for another day. Calculates total costs for meals.
    Use: b_total, l_total, s_total, a_total = meal_costs()
    -------------------------------------------------------
    Returns:
        b_total - total breakfasts cost (float)
        l_total - total lunches cost (float)
        s_total - total suppers cost (float)
        a_total - all meals cost (float)
    ------------------------------------------------------
    """
    # Initilizing the variables
    b_total = 0.0
    l_total = 0.0
    s_total = 0.0
    a_total = 0.0

    day = 1
    another_day = "Y"

    # while loop
    while another_day == "Y":
        print(f"For Day {day}\n")
        # Asks for the inputs of breakfast cost, lunch cost and supper cost
        breakfast_cost = float(input(f"How much was breakfast? $"))
        lunch_cost = float(input(f"How much was lunch? $"))
        supper_cost = float(input(f"How much was supper? $"))

        # calculates the total cost of the meal for the day
        day_total = breakfast_cost + lunch_cost + supper_cost

        # total cost of the brekafast
        b_total += breakfast_cost
        # total cost of the lunch
        l_total += lunch_cost
        # total cost of the supper
        s_total += supper_cost
        # total cost of the day
        a_total += day_total

        print(f"Your total for the day was ${day_total:.2f}\n")

        # counts the number of days
        day += 1

        # asks the user if they had a meal for another day
        another_day = input("Were you away another day (Y/N)? ")

    return b_total, l_total, s_total, a_total


def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """
    # Constants
    OVERTIME = 40
    TAX_RATE = 3.625 / 100

    CHECK = True
    total = 0
    TOTAL_EMPLOYEES = 0

    # While loop
    while CHECK == True:
        # asks the user for their employee id
        employee_id = int(input("Employee ID: "))
        # checks so that the employee did not enter a 0, if they did it ends the program
        if employee_id == 0:
            break
        # input for the hourly wage and the hours worked
        hourly_wage = float(input("Hourly wage rate: "))
        hours_worked = float(input("Hours worked: "))
        # this will check if the user hit overtinme and calculate for it accordinly
        if hours_worked > OVERTIME:
            overtime_hours = hours_worked - OVERTIME
            overtime_payment = overtime_hours * hourly_wage * 1.5
            regular_payment = OVERTIME * hourly_wage
            total_payment = regular_payment + overtime_payment
        # this will continue with the program if the user did not hit ovetime
        else:
            total_payment = hours_worked * hourly_wage

        # a total amount of 3.625% tax will be deducted from the salary
        tax_deduction = total_payment * TAX_RATE
        net_payment = total_payment - tax_deduction

        # Output
        print(f"Net Payment for employee {employee_id}: {net_payment:0.2f}\n")

        # this will calculate the total salary of all the workers and the average salary.
        total += net_payment
        TOTAL_EMPLOYEES += 1
        average = total / TOTAL_EMPLOYEES

    return total, average
