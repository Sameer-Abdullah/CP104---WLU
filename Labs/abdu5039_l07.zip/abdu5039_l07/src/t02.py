"""
-------------------------------------------------------
[This program will calculate the nearest power of 2 
greater than or equal to a given target by the user.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-01"
-------------------------------------------------------
"""
# Imports
from functions import power_of_two

# gets an input for the traget number
target = int(input("Enter a target number: "))

# Call on the function power_of_two
power = power_of_two(target)

# Output
print(power)
