"""
-------------------------------------------------------
[This program will ask the user for their user id, hourly
rate, and the hours they worked. It will then calculate
how much the user should get paid after taking out a 
tax of 3.625%, it will ask the user if they have any
other employees an continue to do so until the user 
enter 0 for the employee id.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-02"
-------------------------------------------------------
"""
# Imports
from functions import employee_payroll

# this will call on the funtion employee_payroll
total, average = employee_payroll()

# Output
print(f"\nTotal Payment: ${total:.2f}")
print(f"Averge Payment: ${average:.2f}")
