"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-01"
-------------------------------------------------------
"""
# Imports
# Imports
from functions import population_growth

target = int(input("Enter the target population: "))
current = int(input("Enter the current population: "))
rate = float(input("Enter the percent rate of growth: "))

years = population_growth(target, current, rate)

print(years)
