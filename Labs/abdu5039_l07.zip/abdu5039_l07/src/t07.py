"""
-------------------------------------------------------
[This function asks the user for all the meals they had
for breakfast, lunch and supper. The computer will ask 
for the costs of each. The computer will then return
the total for the day and asks if they had a meal another
day, if the user responds Y then the computer will ask 
for the meals once again, once the user enters N for 
another day, the program will quite and return the 
total amount for all the days combined.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-02"
-------------------------------------------------------
"""
# Imports
from functions import meal_costs

# calls on the function meal_costs
b_total, l_total, s_total, a_total = meal_costs()

# Output
print(f"\n{b_total:0.2f}, {l_total:0.2f}, {s_total:0.2f}, {a_total:0.2f}")
