"""
-------------------------------------------------------
[This program is essentialy a gussing game, it asks
the user the maximum number they want to guess until
then it will ask them until they get the correct number.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-01"
-------------------------------------------------------
"""
# Imports
from functions import hi_lo_game

# Gets an input for the maximum number to pass
high = int(input("Enter the maximum number to guess: "))

# calls on the function hi_lo_game
count = hi_lo_game(high)
