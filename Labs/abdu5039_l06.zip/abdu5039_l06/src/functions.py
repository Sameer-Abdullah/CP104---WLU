"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""


# function for t01.py
def sum_even(num):
    """
    -------------------------------------------------------
    Sums and returns the total of all even numbers from 2 to num (inclusive).
    Use: total = sum_even(num)
    -------------------------------------------------------
    Parameters:
        num - an integer (int > 0)
    Returns:
        total - sum of all even numbers from 2 to num (int)
    ------------------------------------------------------
    """
    # Initizling a variable to keep the even numbers in
    total = 0

    # This is a for lop, that will loop from 2 to num(number entred by user), with a step of 2
    for s in range(2, num + 1, 2):
        total += s

    # returns total
    return total

# function for t05.py


def draw_rectangle(height, width, char):
    """
    -------------------------------------------------------
    Prints a rectangle of height and width characters using
    the char character.
    Use: draw_rectangle(height, width, char)
    -------------------------------------------------------
    Parameters:
        height - number of characters high (int > 0)
        width - number of characters wide (int > 0)
        char - the character to draw with (str, len() == 1)
    Returns:
        None
    ------------------------------------------------------
    """
    # This is a for loop, looping for the total amount of times the user entered for the height
    for s in range(height):
        print(char * width)
    return


# function for t09.py
def bottles_of_beer(n):
    """
    -------------------------------------------------------
    Prints n verses of the song "99 Bottles of Beer on the Wall".
    Use: bottles_of_beer(n)
    -------------------------------------------------------
    Parameters:
        n - number of verses of the song to print (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    for bottles in range(n, 0, -1):
        print(f"{bottles} bottles of beer on the wall, {bottles} bottles of beer.\nTake one down, pass it around, {bottles -1} bottle of beer on the wall.")
        print("--")
    return


# function for t10.py
def treadmill(burnt_per_minute, start, end, inc):
    """
    -------------------------------------------------------
    Calculates and prints calories burnt on a treadmill over
    a given time range.
    Use: treadmill(burnt_per_minute, start, end, inc)
    -------------------------------------------------------
    Parameters:
        burnt_per_minute - calories burnt per minute (float > 0)
        start - start time in minutes (int > 0)
        end - end time in minutes (int >= start)
        inc - increment in minutes (int > 0)
    Returns:
        None
    ---------------------------------------------------------
    """
    # This is a for loop starting with the start value stated by the user and the end valur stated by the user also.
    for i in range(start, end + 1, inc):
        burnt_calories = burnt_per_minute * i   # keeps track of the burnet calloris
        print(f"Calories burned after {i} minutes :{burnt_calories}")
    return

# function for t15.py


def statistics(n):
    """
    -------------------------------------------------------
    Asks a user to enter n values, then calculates and returns
    the minimum, maximum, total, and average of those values.
    Use: minimum, maximum, total, average = statistics(n)
    -------------------------------------------------------
    Parameters:
        n - number of values to process (int > 0)
    Returns:
        minimum - smallest of n values (float)
        maximum - largest of n values (float)
        total - total of n values (float)
        average - average of n values (float)
    ------------------------------------------------------
    """
    total = 0       # Intitalzing the variable
    minimum = float('inf')     # Intitalzing the variable
    maximum = float('-inf')     # Intitalzing the variable
    first = float(input("First Value: "))  # input for the first value

    # This is a for loop for the amount of times the stastic should run stated by the user and stores in the varibale n
    for i in range(n-1):
        # input for the rest of the values
        value = float(input("Next Value: "))
        total += value  # keeping track of the total

        # if statment to check for minimum and maximum
        if value < minimum:
            minimum = value
        if value > maximum:
            maximum = value

    # Calculating the total
    total += first

    # Calculating the average
    average = total / n

    # Returns minimum, maximum total, average
    return minimum, maximum, total, average
