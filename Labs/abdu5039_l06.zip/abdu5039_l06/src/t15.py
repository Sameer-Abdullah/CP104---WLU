"""
-------------------------------------------------------
[This program will ask the user for a value to process,
 then takes that value and gives back the minumum, maximum
 and then finds the total and average from there. ]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import statistics

# This will get the user input for a value to process
n = int(input("Enter a value to process: "))

# Calls the function statistics
minimum, maximum, total, average = statistics(n)

# Output
print(f"{minimum:0.2f}, {maximum:0.2f},{total:0.2f}, {average:0.2f} ")
