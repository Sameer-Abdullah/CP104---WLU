"""
-------------------------------------------------------
[This program will draw a rectangle with any height and
width and any given character given by the user]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import draw_rectangle

# Input for the height, width and char ==> the character to draw
height = int(input("Enter the height: "))
width = int(input("Enter the width: "))
char = input("Enter the character to draw with: ")

# calls the function draw_rectangle
draw_rectangle(height, width, char)
