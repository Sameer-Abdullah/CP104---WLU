"""
-------------------------------------------------------
[This program will take the number of verses enterd 
by the user and return that many verses.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import bottles_of_beer

# Gets the input for the number of verses
n = int(input("Enter the number of verses: "))

# calls the function bottles_of_bear with the prameter n
bottles_of_beer(n)
