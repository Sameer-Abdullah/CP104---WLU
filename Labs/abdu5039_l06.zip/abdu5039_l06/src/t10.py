"""
-------------------------------------------------------
[This program will find our the calories burnet for each
time increment based on the user input for the starting
time, end and the increments in minuites.w]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import treadmill

# Input for the burnt_per_minuite, start time, end time, and the increment
burnt_per_minute = float(input("Calories burnt per minute: "))
start = int(input("Start time in minutes: "))
end = int(input("End time in minutes: "))
inc = int(input("Increments in minutes: "))

# Calls the function treadmill
treadmill(burnt_per_minute, start, end, inc)
