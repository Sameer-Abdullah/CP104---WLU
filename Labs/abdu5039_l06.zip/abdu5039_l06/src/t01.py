"""
-------------------------------------------------------
[This program takes a number from the uer and returns the 
sum of all the even numbers]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import sum_even

# Input for a number
num = int(input("Enter a number: "))

# Calls the function sum_even
total = sum_even(num)

# Output
print(total)
