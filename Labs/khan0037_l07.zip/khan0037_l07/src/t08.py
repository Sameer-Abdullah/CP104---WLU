"""
-------------------------------------------------------
[Personal Budget Calculator, This Python program 
calculates the total expenses, remaining balance, and 
financial status based on the available budget. It asks 
the user to input their available budget and a series 
of expenses. The status can be "Surplus" if there's 
extra money, "Deficit" if expenses exceed the budget, 
or "Balanced" if the budget is perfectly balanced.]
-------------------------------------------------------
Author:  Bisma Khan
ID:          169050037
Email:     khan0037@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import budget

# Get user input for the available budget
available = float(input("Enter the amount of money available: $"))

# Call the 'budget' function to calculate expenses, balance, and status
expenses, balance, status = budget(available)

# Display the financial information and status
print(f"Total expenses: ${expenses:.2f}")
print(f"Remaining balance: ${balance:.2f}")
print(f"Status: {status}")
