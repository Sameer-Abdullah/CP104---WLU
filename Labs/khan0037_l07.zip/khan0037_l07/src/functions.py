"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Bisma Khan
ID:          169050037
Email:     khan0037@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from random import randint


from random import randint


def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
    # Initialize variables
    count = 0
    random_guess = -1000  # Initialize random_guess to an impossible value

    # Generate a random number between 1 and 'high'
    number = randint(1, high)

    # Main game loop
    while random_guess != number:
        # Get user's guess
        random_guess = int(input("Guess: "))

        # Increment the guess count
        count += 1

        # Check if the guess is too low or too high
        if random_guess < number:
            print("Too low, try again.")
        elif random_guess > number:
            print("Too high, try again.")
        else:
            # The user guessed correctly
            print("Congratulations - good guess!")
            break  # Exit the loop after a correct guess

    # Display the number of guesses made
    print(f"You made {count} guesses.")

    return count


def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    # Initialize the power to 1 (2^0 is 1)
    power = 1

    # Calculate the nearest power of 2
    while power < target:
        power *= 2

    return power


def positive_statistics():
    """
    -------------------------------------------------------
    Asks a user to enter a series of positive numbers, then calculates
    and returns the minimum, maximum, total, and average of those numbers.
    Stop processing values when the user enters a negative number.
    The first number entered must be positive.
    Use: minimum, maximum, total, average = positive_statistics()
    -------------------------------------------------------
    Returns:
        minimum - smallest of the entered values (float)
        maximum - largest of the entered values (float)
        total - total of the entered values (float)
        average - average of the entered values (float)
    ------------------------------------------------------
    """
    # Constants to keep track of minimum, maximum, total, and count
    minimum = float('inf')  # Initialize minimum to positive infinity
    maximum = float('-inf')  # Initialize maximum to negative infinity
    total = 0  # Initialize total sum to zero
    count = 0  # Initialize count of entered values to zero

    # Get the first positive value from the user
    value = float(input("First positive value: "))

    while value >= 0:
        # Update minimum and maximum values
        if value < minimum:
            minimum = value
        if value > maximum:
            maximum = value

        # Add the value to the total and increment the count
        total += value
        count += 1

        # Get the next positive value from the user
        value = float(input("Next positive value: "))

    if count == 0:
        average = 0.00  # Set average to 0 if no positive values are entered
    else:
        average = total / count

    # Return results rounded to 2 decimal places
    return (round(minimum, 2), round(maximum, 2), round(total, 2), round(average, 2))


def budget(available):
    """
    -------------------------------------------------------
    Asks a user for a series of expenses in a month. Calculate the
    total expenses and determines whether the user is in "Surplus",
    "Deficit", or "Balanced" status.
    Use: expenses, balance, status = budget(available)
    -------------------------------------------------------
    Parameters:
        available - money currently available (float >= 0)
    Returns:
        expenses - total monthly expenses (float)
        balance - remaining balance (float)
        status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            "Balanced" if user budget is balanced
    ------------------------------------------------------
    """
    # Initialize the total expenses to zero
    expenses = 0

    # Continue to prompt the user for expenses until they enter 0 to quit
    while True:
        expense = float(input("Enter an expense (0 to quit): $"))
        if expense == 0:
            break
        expenses += expense

    # Calculate the balance by subtracting total expenses from the available budget
    balance = available - expenses

    # Determine the financial status based on the balance
    if balance > 0:
        status = "Surplus"  # If there's a surplus of funds
    elif balance < 0:
        status = "Deficit"  # If there's a deficit of funds
    else:
        status = "Balanced"  # If the budget is balanced

    # Return the total expenses, balance, and financial status
    return expenses, balance, status


def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """
    # Constants
    OVERTIME = 40  # The threshold for considering overtime hours
    TAX_RATE = 3.625 / 100  # The tax rate as a percentage

    # Initialize variables for tracking financial information and loop control
    running = True  # A flag to control the loop
    total = 0  # Total net employee wages (after taxes)
    total_employees = 0  # Total number of employees

    # Main loop for processing employee information
    while running:
        # Get input for employee information
        employee_ID = int(input("Employee ID: "))

        # Check if the entered employee ID is 0, which indicates the end of input
        if employee_ID == 0:
            break

        # Employee's hourly wage rate
        hourly_rate = float(input("Hourly wage rate: "))
        # Number of hours worked by the employee
        hours_worked = float(input("Hours worked: "))

        # Calculate the payment for the employee
        if hours_worked > OVERTIME:
            overtime_hours = hours_worked - OVERTIME
            overtime_payment = overtime_hours * hourly_rate * 1.5
            regular_payment = OVERTIME * hourly_rate
            total_payment = regular_payment + overtime_payment
        else:
            total_payment = hours_worked * hourly_rate

        # Calculate tax deduction and net payment
        tax_deduction = total_payment * TAX_RATE
        net_payment = total_payment - tax_deduction

        # Display the net payment for the employee
        print(f"Net Payment for employee {employee_ID}: {net_payment:.2f}\n")

        # Update the total and count of employees
        total += net_payment
        total_employees += 1

        # Calculate the average net payment
        average = total / total_employees

    # Return the total net employee wages and the average net payment
    return total, average
