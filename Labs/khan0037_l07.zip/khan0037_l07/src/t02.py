"""
-------------------------------------------------------
[Power of Two Calculator, This Python program calculates 
the nearest power of two that is greater than or equal 
to a given target number.]
-------------------------------------------------------
Author:  Bisma Khan
ID:          169050037
Email:     khan0037@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""

# Imports
from functions import power_of_two

# gets an input for the target number
target = int(input("Enter a target number: "))

# Call on the function power_of_two
power = power_of_two(target)

# Output
print(power)
