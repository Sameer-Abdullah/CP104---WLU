"""
-------------------------------------------------------
[Factorial Calculator, this Python program calculates 
the factorial of a non-negative integer entered by 
the user.]
-------------------------------------------------------
Author:  Bisma Khan
ID:          169050037
Email:     khan0037@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import hi_lo_game

# Gets an input for the maximum number to pass
high = int(input("Enter the maximum number to guess: "))

# calls on the function hi_lo_game
count = hi_lo_game(high)
