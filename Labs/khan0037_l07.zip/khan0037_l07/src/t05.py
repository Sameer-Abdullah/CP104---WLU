"""
-------------------------------------------------------
[Positive Number Statistics Calculator, This Python 
program asks the user to enter a series of positive 
numbers, calculates and returns the minimum, maximum, 
total, and average of those numbers. It stops processing 
values when the user enters a negative number, and the 
first number entered must be positive.]
-------------------------------------------------------
Author:  Bisma Khan
ID:          169050037
Email:     khan0037@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import positive_statistics

# Call the 'positive_statistics' function to calculate statistics
minimum, maximum, total, average = positive_statistics()

# Display the calculated statistics
print(f"Minimum: {minimum:.2f}")
print(f"Maximum: {maximum:.2f}")
print(f"Total: {total:.2f}")
print(f"Average: {average:.2f}")
