"""
-------------------------------------------------------
[Employee Payroll Calculator, This Python program 
calculates the weekly payroll for all employees in an 
organization. It asks the user for each employee's ID, 
hourly wage rate, and hours worked during the week. The 
program automatically calculates payments, including 
overtime rates for hours worked over 40 hours. It also 
deducts a tax amount, and then calculates the total 
payroll and average payment for the employees.]
-------------------------------------------------------
Author:  Bisma Khan
ID:          169050037
Email:     khan0037@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import employee_payroll

# Call the 'employee_payroll' function to calculate payroll information
total, average = employee_payroll()

# Display the total payment and average payment for employees
print(f"\nTotal Payment: ${total:.2f}")
print(f"Average Payment: ${average:.2f}")
