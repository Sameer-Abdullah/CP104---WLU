"""
-------------------------------------------------------
[This program will convert a user entered number from 
1 to 10 and convert it to Roman Numeral.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports
from functions import roman_numeral

# This will get the input for a number from 1 to 10
n = int(input("Enter a number between 1 and 10: "))

# This will call the function roman_numeral
result = roman_numeral(n)

# Output
print(result)
