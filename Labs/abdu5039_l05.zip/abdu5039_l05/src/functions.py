"""
-------------------------------------------------------
[This is the functions.py, all the functions used for 
this lab are here.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# This is the function used for t01.py


def magic_date(day, month, year):
    """
    -------------------------------------------------------
    Determines if a date is magic. A date is magic if the day
    times the month equals the year.
    Use: magic = magic_date(day, month, year)
    -------------------------------------------------------
    Parameters:
        day - numeric day (int > 0)
        month - numeric month (int > 0)
        year - numeric two-digit year (int > 0)
    Returns:
        magic - True if date is magic, False otherwise (boolean)
    --------------------------------------------------------
    """
    if day > 0 and month > 0 and year > 0:
        answer = day * month == year
    else:
        answer = False

    return answer


# This is the function used for t04.py
def closest(target, v1, v2):
    """
    -------------------------------------------------------
    Determines closest value of two values to a target value.
    Use: result = closest(target, v1, v2)
    -------------------------------------------------------
    Parameters:
        target - the target value (float)
        v1 - first comparison value (float)
        v2 - second comparison value (float)
    Returns:
        result - one of v1 or v2 that is closest to target,
          v1 is the value chosen if v1 and v2 are an equal
          distance from target (float)
    -------------------------------------------------------
    """
    if abs(target - v1) <= abs(target - v2):
        number = v1
    else:
        number = v2

    return number


# This is the function used for t08.py
def roman_numeral(n):
    """
    -------------------------------------------------------
    Convert 1-10 to Roman numerals.
    Use: numeral = roman_numeral(n)
    -------------------------------------------------------
    Parameters:
        n - number to convert to Roman numerals (int)
    Returns:
        numeral - Roman numeral version of n, None if n is not
          between 1 and 10 inclusive. (str)
    -------------------------------------------------------
    """
    if 1 <= n <= 10:
        roman_numerals = ["I", "II", "III", "IV",
                          "V", "VI", "VII", "VIII", "IX", "X"]
        roman_return = roman_numerals[n - 1]
    else:
        roman_return = None

    return roman_return


# This is the function used for t12.py
def pay_raise(status, years, salary):
    """
    -------------------------------------------------------
    Calculates pay raises for employees. Pay raises are based on:
    status: Full Time ('F)' or Part Time ('P')
    and years of service
    Raises are:
        5% for full time greater than or equal to 10 years service
        1.5% for full time less than 4 years service
        3% for part time greater than 10 years service
        1% for part time less than 4 years service
        2% for all others
    Use: new_salary = pay_raise(status, years, salary)
    -------------------------------------------------------
    Parameters:
        status - employment type (str - 'F' or 'P')
        years - number of years employed (int > 0)
        salary - current salary (float > 0)
    Returns:
        new_salary - employee's new salary (float).
    -------------------------------------------------------
    """
    FULL_TIMW_10 = 5/100
    FULL_TIME_4 = 1.5/100
    PART_TIME_10 = 3/100
    PART_TIME_4 = 1/100
    OTHER_RAISE = 2/100

    if status == 'F' or status == 'f':
        if years >= 10:
            new_salary = (salary * FULL_TIMW_10) + salary
        elif years < 4:
            new_salary = (salary * FULL_TIME_4) + salary
        else:
            new_salary = (salary * OTHER_RAISE) + salary
    elif status == 'P' or status == 'p':
        if years >= 10:
            new_salary = (salary * PART_TIME_10) + salary
        elif years < 4:
            new_salary = (salary * PART_TIME_4) + salary
        else:
            new_salary = (salary * OTHER_RAISE) + salary
    else:
        new_salary = salary

    return new_salary


# This is the function used for t14.py
def ticket():
    """
    -------------------------------------------------------
    School play ticket price calculation.
    Asks user for their age, and if necessary, if they are
    a student at the school. Prices:
        Infant (age < 3): $0
        Senior (age >= 65): $4.00
        Student (10 <= age < 18): $3.00
            Student of this school: $1.00
        Adult (18 <= age < 65): $5.00
        Kid (3 <= age < 10): $2.00
    Use: price = ticket()
    -------------------------------------------------------
    Returns:
        price - the price of one ticket (float)
    -------------------------------------------------------
    """
    INFANT = 3
    KID = 10
    STUDENT_MIN = 10
    STUDENT_MAX = 18
    ADULT_MIN = 18
    ADULT_MAX = 65
    SENIOR = 65

    age = int(input("Please enter your age: "))

    if age < INFANT:
        price = 0.00
    elif age >= SENIOR:
        price = 4.00
    elif KID <= age < STUDENT_MIN:
        price = 2.00
    elif STUDENT_MIN <= age < STUDENT_MAX:
        student = input("Are you a student at this school? (Y/N): ")
        if student == "Y" or student == "y":
            price = 1.00
        else:
            price = 3.00
    elif ADULT_MIN <= age < ADULT_MAX:
        price = 5.00
    else:
        price = ticket()

    return price
