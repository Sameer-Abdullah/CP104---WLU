"""
-------------------------------------------------------
[This program will ask the user about their age and 
them give the user how much their ticket will cost]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports
from functions import ticket

# This will call the ticket() function
price = ticket()

# Output
print(f"${price:.2f}")
