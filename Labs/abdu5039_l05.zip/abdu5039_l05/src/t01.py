"""
-------------------------------------------------------
[This program will will check if a given date is a magic
date or not. To check if a date is a magic date the 
day * month = last two digit of the year]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports
from functions import magic_date

# Gets the input for the day, month, and year
day = int(input("Enter the day: "))
month = int(input("Enter the month: "))
year = int(input("Enter the two-digit year: "))

# Check if the date is magic
it_is_magic = magic_date(day, month, year)

# Output
print(it_is_magic)
