"""
-------------------------------------------------------
[ This program is designed to find the closest value to 
a targeted value.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports
from functions import closest

# Gets the input for the target, v1 and v2
target = float(input("Enter the target value: "))
v1 = float(input("Enter the first value (v1): "))
v2 = float(input("Enter the second value (v2): "))

# This will call the closest function
result = closest(target, v1, v2)

# Output
print(f"The closest value to {target} is {result}")
