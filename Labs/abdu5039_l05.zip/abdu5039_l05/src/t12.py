"""
-------------------------------------------------------
[This program will ask the user if they are a part time 
employee or a full time employee, based on their input
the computer will ask them for their salary and give them
a raise depending on the amount of years they worked and 
if they are a part or full time employee.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""
# Imports
from functions import pay_raise

# This will get the input for the status, number of year and current salary
status = str(input("Enter your status as 'F' or 'P': "))
years = int(input("Number of employed years: "))
salary = float(input("Current salary: "))

# This will take pay_raise as an argument
new_salary = pay_raise(status, years, salary)

# Output
print(f"{new_salary:0.2f}")
