"""
-------------------------------------------------------
[This program serves to parse a given product code 
and determine the validity of its three distinct parts:
 category, digits, and qualifiers.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-14"
-------------------------------------------------------
"""
# Imports
from functions import validate_code

# Input
product_code = input("A product code: ")

# Calls on the function validate_code
category, digits, qualifiers = validate_code(product_code)

# Output
print(category, digits, qualifiers)
