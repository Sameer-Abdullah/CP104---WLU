"""
-------------------------------------------------------
[analyizses text for upper case, lower case.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports
from functions import text_analyze

# Input
txt = input("The text to be analyzed: ")

# Calls on the function text_analyze
uppr, lowr, dgts, whtspc = text_analyze(txt)

# Output
print(uppr, lowr, dgts, whtspc)
