"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports


def is_hydroxide(chemical):
    """
    -------------------------------------------------------
    Determines if a chemical formula is a hydroxide.
    Use: hydroxide = is_hydroxide(chemical)
    -------------------------------------------------------
    Parameters:
        chemical - a chemical formula (str)
    Returns:
        hydroxide - True if chemical is a hydroxide (ends in 'OH'),
            False otherwise (boolean)
    -------------------------------------------------------
    """
    # Check if the chemical formula ends with 'OH'
    if chemical.endswith("OH"):
        hydroxide = True
    else:
        hydroxide = False
    # Returns the value of hydroxide
    return hydroxide


def parse_code(product_code):
    """
    -------------------------------------------------------
    Parses a given product code. A product code has three parts:
        The first three letters describe the product category
        The next four digits are the product ID
        The remaining characters describe the product's qualifiers
    Use: pc, pi, pq = parse_code(product_code)
    -------------------------------------------------------
    Parameters:
        product_code - a valid product code (str)
    Returns:
        pc - the category part of product_code (str)
        pi - the id part of product_code (str)
        pq - the qualifier part of product_code (str)
    -------------------------------------------------------
    """
    # Extract the first three letters as the category
    pc = product_code[:3]

    # Extract the next four digits as the product ID
    pi = product_code[3:7]

    # Extract the remaining characters as the qualifiers
    pq = product_code[7:]

    # Return the parsed components
    return pc, pi, pq


def validate_code(product_code):
    """
    -------------------------------------------------------
    Parses a given product code and prints whether the various parts are valid.
    A product code has three parts:
        The first three letters describe the product category and must
        all be in upper case.
        The next four digits are the product ID.
        The remaining characters describe the product's qualifiers,
        such as colour, size, etc. and always begins with an uppercase letter.
    Use: category, digits, qualifiers = validate_code(product_code)
    -------------------------------------------------------
    Parameters:
        product_code - a product code (str)
    Returns:
        category - True if three upper-case characters, False otherwise
        digits - True if four digits, False otherwise
        qualifiers - True if starts with 1 upper-case letter, False otherwise
    -------------------------------------------------------
    """
    # Check the category (first three letters in upper case)
    category = len(product_code) >= 3 and product_code[:3].isalpha(
    ) and product_code[:3].isupper()

    # Check the digits (next four characters are digits)
    digits = len(product_code) >= 7 and product_code[3:7].isdigit()

    # Check the qualifiers (starts with an uppercase letter)
    qualifiers = len(product_code) >= 8 and product_code[7].isalpha(
    ) and product_code[7].isupper()

    return category, digits, qualifiers


def password_strength(password):
    """
    -------------------------------------------------------
    Checks the strength of a given password. A password is
    strong if it contains at least eight characters, has a
    combination of upper-case and lower-case letters, and
    includes digits. Prints one or more of:
        not long enough - if password less than 8 characters
        no digits - if password has no digits
        no upper case - if password has no upper case letters
        no lower case - if password has no lower case letters
    Use: password_strength(password)
    -------------------------------------------------------
    Parameters:
        password - the password to be checked (str)
    Returns:
        None
    ------------------------------------------------------
    """
    # Check the length of the password
    if len(password) < 8:
        print("not long enough")

    # Check for the presence of digits, upper case, and lower case letters
    if not any(char.isdigit() for char in password):
        print("no digits")
    if not any(char.isupper() for char in password):
        print("no upper case")
    if not any(char.islower() for char in password):
        print("no lower case")
    return None


def text_analyze(txt):
    """
    -------------------------------------------------------
    Analyzes txt and returns the number of uppercase letters,
    lowercase letters, digits, and number of whitespaces in txt.
    Use: uppr, lowr, dgts, whtspc = text_analyze(txt)
    -------------------------------------------------------
    Parameters:
        txt - the text to be analyzed (str)
    Returns:
        uppr - number of uppercase letters in txt (int >= 0)
        lowr - number of lowercase letters in txt (int >= 0)
        dgts - number of digits in txt (int >= 0)
        whtspc - number of white spaces in the text (spaces, tabs, linefeeds) (int >= 0)
    ------------------------------------------------------
    """
    # Initialize counters
    uppr = lowr = dgts = whtspc = 0

    # Analyze the text
    for char in txt:
        if char.isupper():
            uppr += 1
        elif char.islower():
            lowr += 1
        elif char.isdigit():
            dgts += 1
        elif char.isspace():
            whtspc += 1

    # Returns the value of uppr, lowr, dgts, whtspc
    return uppr, lowr, dgts, whtspc
