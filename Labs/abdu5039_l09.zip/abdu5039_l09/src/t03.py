"""
-------------------------------------------------------
[Parses a given product code. A product code has three parts:
The first three letters describe the product category
The next four digits are the product ID
The remaining characters describe the product's qualifiers
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports
from functions import parse_code

# Input
product_code = input("Enter a product code: ")

# Calls on the function parse_code
pc, pi, pq = parse_code(product_code)

# Output
print(pc, pi, pq)
