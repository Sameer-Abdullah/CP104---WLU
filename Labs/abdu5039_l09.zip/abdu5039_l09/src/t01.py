"""
-------------------------------------------------------
[This program checks if a chemical name ends with OH]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports
from functions import is_hydroxide

# Input
chemical = input("A chemical formula: ")

# Calls on the function is_hydroxide
hydroxide = is_hydroxide(chemical)

# Output
print(hydroxide)
