"""
-------------------------------------------------------
[This program check the strength of a password]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
# Imports
from functions import password_strength

# Input
password = input("The Password to be checked: ")

# Calls on the function password_strength
password_strength(password)

# Output
print(password_strength)
