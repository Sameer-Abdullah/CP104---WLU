"""
-------------------------------------------------------
[This program will calculate the volume of a square
pyramid.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
# Imports
from functions import square_pyramid

# Input for the user to enter the base and height values
base = float(input("Enter the base: "))
height = float(input("Enter the height: "))

# Call the square_pyramid function to calculate the volume
volume = square_pyramid(base, height)

# Output
print(f"{volume}")
