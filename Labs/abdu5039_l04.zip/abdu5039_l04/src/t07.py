"""
-------------------------------------------------------
[This [program is designed to calculate the total of how
much some some nickles, dimes, quarter...etc.. will come 
out to. Given the input of the number of coins from the 
user. This program will use the functions.py for a function
named total_change]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
# Imports
from functions import total_change

# Input for the number of nickles, dimes, quarters, toonies and loonies
number_of_nickels = int(input("Number of nickels: "))
number_of_dimes = int(input("Number of dimes: "))
number_of_quarters = int(input("Number of quarters: "))
number_of_loonies = int(input("Number of loonies: "))
number_of_toonies = int(input("Number of toonies: "))

# Call the total_change function to calculate the total value of coins
total = total_change(number_of_nickels, number_of_dimes,
                     number_of_quarters, number_of_loonies, number_of_toonies)

# Output
print(f"Total value of coins: ${total:.2f}")
