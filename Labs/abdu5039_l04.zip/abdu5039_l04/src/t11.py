"""
-------------------------------------------------------
[This program will take the x and y coordinates from the
user and find the slope between the two points. Linear]
-------------------------------------------------------
Author: Sameer Abdullah
ID: 169065039
Email: abdu5039@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
# Import
from functions import slope

# Input for the x1, x2 and y1,y2
x1 = float(input("Enter x1: "))
x2 = float(input("Enter x2: "))
y1 = float(input("Enter y1: "))
y2 = float(input("Enter y2: "))

# Calculate the slope of the line
slp = slope(x1, y1, x2, y2)

# Output
print(f"Slope: {slp:.2f}")
