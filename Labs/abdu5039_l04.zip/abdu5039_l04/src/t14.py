"""
-------------------------------------------------------
[This program will ask the user for the time in seconds
then convert it in to how long it is for the minutes, 
hours and days. ]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
# Imports
from functions import time_values

# input for the time in seconds
seconds = int(input("Enter time in seconds: "))

# Call the time_values function to convert seconds
days, hours, minutes = time_values(seconds)

# Output
print(f"({minutes:d}, {hours:d}, {days:d})")
