"""
-------------------------------------------------------
[This program will calculate the diameter of a circle, 
with a radius given from the function called diameter.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
# Import the diameter function from the functions module
from functions import diameter

# Define the radius of the circle
radius = float(input("Enter the radius: "))

# This will calculate the diameter of the circle using the diameter function
diam = diameter(radius)

# Output
print(f"The diameter of the circle with radius {radius} is {diam}")
