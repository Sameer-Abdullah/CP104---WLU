"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import linear_search

# Gets the input for the list of values
values_str = input("Enter a list of values separated by spaces: ")
values = [int(val) for val in values_str.split()]


# Gets the user input for a value to search for
value = int(input("Enter the value to search for: "))

# calls on the function linear_search with the parameters(values, value) and assigns its values to index
index = linear_search(values, value)

# Output
print(index)
