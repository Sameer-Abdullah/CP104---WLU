"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import generate_integer_list

# Inputs for the number of values to generate, lowest and highest number
n = int(input("Number of values to generate: "))
low = int(input("Lowest number to generate: "))
high = int(input("Highest number to generate: "))

# calls on the function generate_integer_list with the parameters n, low, high
values = generate_integer_list(n, low, high)

# Output
print(values)
