"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import min_search

# Gets the input for the list of values
values_str = input("Enter a list of values separated by spaces: ")
values = [int(val) for val in values_str.split()]

# Calls on the function min_search and assigns its value to indexes
indexes = min_search(values)

# Output
print(indexes)
