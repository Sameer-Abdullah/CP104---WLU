
"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import list_stats
from functions import generate_integer_list

# Gets the input for the number of values to generate, higest and lowest numbers
n = int(input("Number of values to generate: "))
low = int(input("Lowest number to generate: "))
high = int(input("Highest number to generate: "))

# calls on the function generate_integer_lits and assigns all the values to the valus variable
values = generate_integer_list(n, low, high)

# Calls on the function list_stats with the paramters values
smallest, largest, total, average = list_stats(values)

# Outputs
print(values)
print(smallest, largest, total, average)
