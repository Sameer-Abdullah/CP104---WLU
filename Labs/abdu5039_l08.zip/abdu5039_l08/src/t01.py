"""
-------------------------------------------------------
[This program will ask the user for a number for the day
then uses a list to tell the user what day corrsponds with 
the number they entered.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from functions import get_weekday_name

# input for the number to corrspond with the day
d = int(input("Enter the day of week number: "))

# calls on the function get_weekday_name with the prameter d
name = get_weekday_name(d)

# output
print(name)
