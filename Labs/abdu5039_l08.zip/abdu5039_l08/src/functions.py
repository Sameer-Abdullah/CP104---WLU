"""
-------------------------------------------------------
[functions.py]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-09"
-------------------------------------------------------
"""
# Imports
from random import randint


def get_weekday_name(d):
    """
    -------------------------------------------------------
    Returns the name of a day of the week given its number.
    Use: name = get_weekday_name(d)
    -------------------------------------------------------
    Parameters:
        d - day of week number (1 <= int <= 7)
    Returns:
        name - matching day of the week, 1 = "Sunday", 7 = "Saturday" (str)
    -------------------------------------------------------
    """
    # Creates a string list with the the messeges inside below.
    list = ["Sunday", "Monday", "Tuesday",
            "Wednesday", "Thursday", "Friday", "Saturday"]

    # This vairbale will take in the value of the d - 1 location in the list
    name = list[d - 1]

    # This will return name
    return name


def generate_integer_list(n, low, high):
    """
    -------------------------------------------------------
    Generates a list of random integers.
    Requires import: from random import randint
    Use: values = generate_integer_list(n, low, high)
    -------------------------------------------------------
    Parameters:
        n - number of values to generate (int, > 0)
        low - low value range (int)
        high - high value range (int, > low)
    Returns:
        values - a list of random integers (list of int)
    -------------------------------------------------------
    """
    # This will create a empty list and assign it to the variable named list
    list = []

    # This is a for loop, looping n number of times, n is entered by the user
    for i in range(n):
        # This will use phytons intergreated moudle of random.randint to assign a random num from high, low to the values variable
        values = randint(low, high)
        # This will take that random number and add it to the end of the list
        list.append(values)
    # This will return the list
    return list


def list_stats(values):
    """
    -------------------------------------------------------
    Returns statistics about values in a list.
    values has at least one element.
    Use: smallest, largest, total, average = list_stats(values)
    -------------------------------------------------------
    Parameters:
        values - a list of values (list of float)
    Returns:
        smallest - the smallest number in values (float)
        largest - the largest number in values (float)
        total - total of numbers in list (float)
        average - the average numbers in values (float)
    -------------------------------------------------------
    """
    # smallest
    smallest = largest = values[0]
    total = 0

    # This is a for loop for values amount of times, values is a list
    for num in values:
        # this is a if statment which checks if the number is smallest
        if num < smallest:
            smallest = num
        elif num > largest:
            largest = num
        # Since this is is the total and its inside the for loop it will keep adding num to total each time giving us the total.
        total += num
    # This is the average
    average = total / len(values)

    # returns smallest, largest, average.
    return smallest, largest, total, average


def linear_search(values, value):
    """
    -------------------------------------------------------
    Searches through values for value and returns its index.
    User: index = linear_search(values, value)
    -------------------------------------------------------
    Parameters:
        values - a list of values (list of *).
        value - can be compared to items in values (*).
    Returns:
        index - the index of the location of value in values,
            -1 if not found (int).
    -------------------------------------------------------
    """
    index = -1  # Initialize the index to -1
    i = 0  # Initialize i to 0

    while i < len(values):
        if value == values[i]:
            index = i
            break  # Update the index if the value is found
        i += 1  # Move to the next index

    return index  # Return the final index (either the found index or -1)


def min_search(values):
    """
    -------------------------------------------------------
    Searches through values for the minimum value(s) and returns a
    list of the indexes of those values. (Assumes values has at least
    one element.)
    User: indexes = min_search(values)
    -------------------------------------------------------
    Parameters:
        values - a list of values (list of *).
    Returns:
        indexes - a list of indexes of the minimum values in
            values (list of int).
    -------------------------------------------------------
    """
    # Initilizzes the variable
    min_value = 0

    # Creates a empty list and assigns it to the variable indexes
    indexes = []

    # Creates a for loop with the reange of values
    for i in range(len(values)):
        # checks if values in the [i] slot of the list is smaller then min_value
        if values[i] < min_value:
            min_value = values[i]
            indexes = [i]
        elif values[i] == min_value:
            indexes.append(i)

    # returns indexes
    return indexes
