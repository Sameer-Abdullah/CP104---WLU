"""
-------------------------------------------------------
[This program uses a single print function and double 
triple quotes to print the following code?]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-27"
-------------------------------------------------------
"""
# Outputs
print("""'I'm a Little Astronaut' by Jean Warren

I'm a little astronaut
    Flying to the moon.
        My rocket is ready,
        We blast off soon.
I climb aboard
    And close the hatch.
        5-4-3-2-1, off we blast!""")
