"""
-------------------------------------------------------
[This program will ask the user for the price of their
breakfast, lunch and supper then find the total of them 
all.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-27"
-------------------------------------------------------
"""
# Getting the input for the cost of breakfast, lunch and supper
breakfast = float(input("Enter cost of breakfast: "))
lunch = float(input("Enter cost of lunch: "))
supper = float(input("Enter cost of supper: "))

# Getting the total cost for the whole days meal
total = breakfast + lunch + supper

# Outputs
print("Meal         Cost")
print(f"Breakfast   ${breakfast:6.2f}")
print(f"Lunch       ${lunch:6.2f}")
print(f"Supper      ${supper:6.2f}")
print(f"Total       ${total:6.2f}")
