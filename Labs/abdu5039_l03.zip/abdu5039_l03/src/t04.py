"""
-------------------------------------------------------
[This program will take a value then figure out the 
discount that is enterd by the user and give out a 
output in the form xx.x]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-27"
-------------------------------------------------------
"""
# Getting the input for the number and the discount percentage
number = float(input("Enter number: "))
percent = float(input("Enter percent: "))

# Changing the percentage to decimal then calculating the discount
decmial = percent / 100
discount = number * decmial

# Output
print(f"A {percent} percent discount on {number} is {discount:.1f}")
