"""
-------------------------------------------------------
[This program will use the statements and format them as such
left-------------
-----middle------
------------right]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-27"
-------------------------------------------------------
"""
# Statements
location1 = "left"
location2 = "middle"
location3 = "right"

# Formated statement
print(f"{location1:-<20s}")
print(f"{location2:-^20s}")
print(f"{location3:->20s}")
