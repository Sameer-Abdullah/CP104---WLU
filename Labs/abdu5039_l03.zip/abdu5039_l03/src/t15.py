"""
-------------------------------------------------------
[This program will take the below statments and attmpet
integer ==> integer
integer ==> floating point
integer ==> string
decimal ==> integer
decimal ==> floating point
decimal ==> string
phrase ==> floating point
phrase ==> integer
phrase ==> string]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-27"
-------------------------------------------------------
"""

# Assignment statements
integer = 654321
decimal = 654.32
phrase = "Hello World"

# Print integer as an integer
print(f"Integer as an integer: {integer:d}")


# Print integer as a floating point
print(f"Integer as a floating point: {integer:0.1f}")


# Print decimal as an integer
print(f"Decimal as an integer: {decimal:d}")


# Print decimal as a floating point
print(f"Decimal as a floating point: {decimal:0.1f}")


# Print phrase as a string
print(f"Phrase as a string: {phrase:s}")


# These lines below need to commented out
# print(f"Phrase as a floating point: {phrase:0.1f}")
# print(f"Phrase as an integer: {phrase:d}")
# print(f"Decimal as a string: {decimal:s}")
# print(f"Integer as a string: {integer:s}")
