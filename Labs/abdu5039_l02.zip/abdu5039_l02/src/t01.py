"""
-------------------------------------------------------
[This Program uses the formula f = 9/5c + 32 to convert 
a celsius temperature to fahrenheit]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:      169065039
Email:   abdu5039@mylaurier.ca
__updated__ = "2023-09-19"
-------------------------------------------------------
"""
# Imports

# Getting the input from the user in celsius temperature
celsius = int(input("Temperature (C): "))

# Constants
FAHRENHEIT_FREEZING = 32
F_C_RATIO = 9/5

# converting celsius to farenheit using the forumla f = 9/5c + 32
fahrenheit = F_C_RATIO * celsius + FAHRENHEIT_FREEZING

# Output
print("Temperature (F):", fahrenheit)
