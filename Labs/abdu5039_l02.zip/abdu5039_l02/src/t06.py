"""
-------------------------------------------------------
[This program uses an equation to calculate the monthly
payments of a mortgage when the principle, number of term
and the yearly interest rate is already given.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:      169065039
Email:   abdu5039@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""
# Imports

# User input for the principle amount, term years and the annual interest rate
principal_amount = int(input("Mortgage principal ($): "))
num_years = int(input("Number of years: "))
yearly_intrest_rate = float(input("Yearly interest rate (%):"))

# Calculating the monthly interest rate by dividing the yearly interest rate by 100 to get decimal then 12 to get in months
monthly_intrest_rate = (yearly_intrest_rate / 100) / 12

# Calculating the total amount of monthly payments needed.
total_payments = num_years * 12

# Using the formula, calculating the monthly payments
monthly_payments = principal_amount * (monthly_intrest_rate * (
    1 + monthly_intrest_rate) ** total_payments) / ((1 + monthly_intrest_rate) ** total_payments - 1)

# Output
print("\nThe monthly payments are: $", monthly_payments)
