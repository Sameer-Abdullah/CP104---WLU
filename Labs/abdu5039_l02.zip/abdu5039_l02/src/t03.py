"""
-------------------------------------------------------
[ This program will ask will calculate the income of a 
business of grooming, a large dog for $75.00 and a small
dog for $50.00. It would ge the number of small and large
dogs and return the total the business made for the day.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:      169065039
Email:   abdu5039@mylaurier.ca
__updated__ = "2023-09-19"
-------------------------------------------------------
"""
# Imports

# Getting inital input from the user, for both small and large dog
number_large_dogs = int(input("Number of Large dogs groomed: "))
number_small_dogs = int(input("Number of Small dogs groomed: "))

LARGE_DOGS_COST = 75.00
SMALL_DOGS_COST = 50.00
# Multiplying the users input with the cost of the dog, then storing in a varibale
large_dog = (number_large_dogs) * (LARGE_DOGS_COST)
small_dog = (number_small_dogs) * (SMALL_DOGS_COST)

# Adding the grand total for the day
total = (large_dog) + (small_dog)

# Output
print("\nTotal earned for the day: $", total)
