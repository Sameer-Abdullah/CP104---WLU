"""
-------------------------------------------------------
[This program calculates the BMI(Body Mass Index) and 
BMI Prime for the user. 
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""
# Imports

# Getting the input for the height, weight and the upper limit bmi
height = float(input("Enter your height (m): "))
weight = float(input("Enter your weight (kg): "))
upper_limit_bmi = int(input(
    "Enter your upper limit BMI (23 if you are from South East Asia and Southern China, 25 for everyone else):"))

# Calculating the BMi using the weight and height^2
body_mass_index = weight / height**2

# calculating the BMI prime using the BMI and upper_limit_bmi
body_mass_prime = body_mass_index / upper_limit_bmi

# Output
print("Body Mass Index (kg/m^2) =", body_mass_index)
print("BMI Prime =", body_mass_prime)
