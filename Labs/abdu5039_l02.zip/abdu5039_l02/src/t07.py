"""
-------------------------------------------------------
[This program asks the user for the number of flyers then
distributes them evenly between the volunteers, any left 
overs will be reported back. ]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""
# Imports

# Getting the input for the number of flyers/volunteers
num_flyers = int(input("Number of flyers: "))
num_volunteers = int(input("Number of volunteers: "))

# Calculating the number of flyers per volunteer using the integer division //
flyers_per_volunteer = num_flyers // num_volunteers

# Using the % operator we get the left over flyers
fryers_left_over = num_flyers % num_volunteers

# Output
print("\nFlyers per volunteer:", flyers_per_volunteer)
print("Flyers left over:", fryers_left_over)
