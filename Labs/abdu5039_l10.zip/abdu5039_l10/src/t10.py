"""
-------------------------------------------------------
[This Python program reads a file named "words.txt," 
takes user input for a specific word, and then counts 
the frequency of that word within the file. It imports 
a function named count_frequency_word from a module 
named functions.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-21"
-------------------------------------------------------
"""
# Imports
from functions import count_frequency_word

# Open the file for reading
file_path = 'words.txt'
file_handle = open(file_path, 'r')

# Take user input for the word to count
word_to_count = input("Word to count: ")

# Call the function to count the frequency of the word
count = count_frequency_word(file_handle, word_to_count)

# Display the result
print(f"'{word_to_count}' appears {count} time(s)")

# Close the file after reading
file_handle.close()
