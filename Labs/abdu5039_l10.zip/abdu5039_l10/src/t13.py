"""
-------------------------------------------------------
[This Python program copies the contents of one file 
(source file) to another file (target file). It imports 
a function named file_copy from a module named functions.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-21"
-------------------------------------------------------
"""
# Imports
from functions import file_copy

# Open the source file for reading
source_file_path = 'words.txt'
source_file_handle = open(source_file_path, 'r')

# Open the target file for writing (creating it if it doesn't exist)
target_file_path = 'new_words.txt'
target_file_handle = open(target_file_path, 'w')

# Call the function to copy the contents from source to target
file_copy(source_file_handle, target_file_handle)

# Close both files after copying
source_file_handle.close()
target_file_handle.close()

print(f"Copying '{source_file_path}' to '{target_file_path}' complete.")
