"""
-------------------------------------------------------
[This Python program is designed to retrieve customer 
records from a file and display them. It imports a 
function named customer_record from a module named 
functions.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-21"
-------------------------------------------------------
"""
# Imports
from functions import customer_record

n = int(input("The number of record to return: "))

fh = open("customers.txt", "r", encoding="utf-8")


result = customer_record(fh, n)
fh.close()

print(result)
