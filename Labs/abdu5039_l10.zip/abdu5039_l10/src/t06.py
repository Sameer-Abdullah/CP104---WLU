"""
-------------------------------------------------------
[This Python program reads a file named "numbers.txt," 
calculates statistics on the numbers within the file, 
and displays the results. It imports a function named 
number_stats from a module named functions.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-21"
-------------------------------------------------------
"""
# Imports
from functions import number_stats

# Open the file for reading
file_path = 'numbers.txt'
file_handle = open(file_path, 'r')

# Call the function to get number statistics
smallest, largest, total, average = number_stats(file_handle)

# Display the results
print(f"Smallest: {smallest}")
print(f"Largest: {largest}")
print(f"Total: {total:.2f}")
print(f"Average: {average:.2f}")

# Close the file after reading
file_handle.close()
