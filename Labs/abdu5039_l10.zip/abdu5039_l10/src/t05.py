"""
-------------------------------------------------------
[This Python program is designed to interactively take 
user input for customer information and append it to a 
file. It imports a function named customer_append from 
a module named functions.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-21"
-------------------------------------------------------
"""
# Imports
from functions import customer_append

# Open the file for appending
file_path = 'customers.txt'
file_handle = open(file_path, 'a')

# Take user input for customer information
customer_data = input(
    "Enter customer information (ID, First Name, Last Name, Balance, Date Joined): ")
customer_data = customer_data.split(',')

# Call the function to append the data to the file
customer_append(file_handle, customer_data)

# Close the file after appending
file_handle.close()

print()
