"""
-------------------------------------------------------
[This program demonstrates the use of the words_to_matrix 
function from the functions module. The program prompts 
the user to input a list of words separated by spaces. 
It then calls the words_to_matrix function to convert 
the list of words into a matrix, where each word becomes 
a row in the matrix. Finally, it prints the resulting matrix.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-28"
-------------------------------------------------------
"""
# Imports
from functions import words_to_matrix

# Take user input for the list of words
user_input = input("Enter a list of words separated by spaces: ")
word_list = user_input.split()

# calls on the function word_to_matrix
matrix = words_to_matrix(word_list)

# Display the result
print(matrix)
