"""
-------------------------------------------------------
[functions.py]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-28"
-------------------------------------------------------
"""
# Imports
import random


def generate_matrix_num(rows, cols, low, high, value_type):
    """
    -------------------------------------------------------
    Generates a 2D list of numbers of the given type, 'float' or 'int'.
    (To generate random float number use random.uniform and to
    generate random integer number use random.randint)
    Use: matrix = generate_matrix_num(rows, cols, low, high, value_type)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the list (int > 0)
        cols - number of columns (int > 0)
        low - low value of range (float)
        high - high value of range (float > low)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        matrix - a 2D list of random numbers (2D list of float/int)
    --------------------------------------------------------
    """
    if value_type == 'float':
        generate_value = random.uniform
    elif value_type == 'int':
        generate_value = random.randint
    else:
        raise ValueError("Invalid value_type. Use 'float' or 'int'.")

    matrix = [[generate_value(low, high) for _ in range(cols)]
              for _ in range(rows)]
    return matrix


def generate_matrix_char(rows, cols):
    """
    -------------------------------------------------------
    Generates a 2D list of random lower case letter ('a' - 'z') values
    Use: matrix = generate_matrix_char(rows, cols)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the generated matrix (int > 0)
        cols - number of columns in the generated matrix (int > 0)
    Returns:
        matrix - a 2D list of random characters (2D list of str)
    -------------------------------------------------------
    """
    # Generate the 2D list using a nested list comprehension
    matrix = [[random.choice('abcdefghijklmnopqrstuvwxyz')
               for _ in range(cols)] for _ in range(rows)]

    return matrix


def words_to_matrix(word_list):
    """
    -------------------------------------------------------
    Generates a 2D list of character values from the given
    list of words. All words must be the same length.
    Use: matrix = words_to_matrix(word_list)
    -------------------------------------------------------
    Parameters:
        word_list - a list containing the words to be placed in
            the matrix (list of string)
    Returns:
        matrix - a 2D list of characters of the given words
         in word_list (2D list of string).
    -------------------------------------------------------
    """
    # Ensure all words in the list have the same length
    word_length = len(word_list[0])
    if not all(len(word) == word_length for word in word_list):
        raise ValueError("All words in the list must be the same length.")

    # Generate the 2D list using a nested list comprehension
    matrix = [[char for char in word] for word in word_list]

    return matrix


def matrix_stats(matrix):
    """
    -------------------------------------------------------
    Returns statistics on a 2D list.
        Use: smallest, largest, total, average = matrix_stats(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of numbers (2D list of float/int)
    Returns:
        smallest - the smallest number in matrix (float/int)
        largest - the largest number in matrix (float/int)
        total - the total of the numbers in matrix (float/int)
        average - the average of numbers in matrix (float/int)
    -------------------------------------------------------
    """
    # Flatten the matrix to a 1D list
    flat_matrix = [num for row in matrix for num in row]

    # Calculate statistics
    smallest = min(flat_matrix)
    largest = max(flat_matrix)
    total = sum(flat_matrix)
    average = total / len(flat_matrix)

    return smallest, largest, total, average


def matrix_scalar_multiply(matrix, num):
    """
    -------------------------------------------------------
    Update matrix by multiplying each element of matrix by num.
    Use: matrix_scalar_multiply(matrix, num)
    -------------------------------------------------------
    Parameters:
        matrix - the matrix to multiply (2D list of int/float)
        num - the number to multiply by (int/float)
    Returns:
        None
    ------------------------------------------------------
    """
    for i in range(len(matrix)):
        for j in range(len(matrix[0])):
            matrix[i][j] *= num

    return None
