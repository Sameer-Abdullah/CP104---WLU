"""
-------------------------------------------------------
[This program demonstrates the use of the matrix_stats 
function from the functions module The program prompts 
the user to enter rows of a matrix, with each element 
in a row separated by spaces. It then converts the input 
into a list of lists, where each row is a list of 
floating-pointnumbers. After that, it calls the matrix_stats 
function to calculate the smallest, largest, total,and 
average values of the matrix. Finally, it prints the 
computed statistics.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-28"
-------------------------------------------------------
"""
# Imports
from functions import matrix_stats

rows_input = input(
    "Enter rows separated by spaces (each element in a row separated by space): ").split()

# Create a list of lists by splitting each row
# Note: You can customize the conversion of elements based on your specific needs
matrix = [list(map(float, row.split())) for row in rows_input]

# Calls on the function matrix_stats
smallest, largest, total, average = matrix_stats(matrix)

# Output
print(smallest, largest, total, average)
