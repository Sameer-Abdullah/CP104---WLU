"""
-------------------------------------------------------
[This program demonstrates the use of the generate_matrix_num 
function from the functions module.The program prompts the 
user to input the number of rows, columns, the low and high 
values for the range,and the type of values (int or float). 
It then calls the generate_matrix_num function to create a 
matrix with random values within the specified range and 
of the specified type. Finally, it prints the generated 
matrix.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-28"
-------------------------------------------------------
"""
# Imports
from functions import generate_matrix_num

# input for the rows, cols, low, high, value type
rows = int(input("Number of rows: "))
cols = int(input("Number of colums: "))
low = float(input("Low value of range: "))
high = float(input("High value of range: "))
value_type = input("Type of value: ")

# calls on the functions generate_matrix_ num
matrix = generate_matrix_num(rows, cols, low, high, value_type)

# Output
print(matrix)
