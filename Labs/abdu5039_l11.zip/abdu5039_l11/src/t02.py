"""
-------------------------------------------------------
[This program demonstrates the use of the generate_matrix_char 
function from the functions module.The program prompts 
the user to input the number of rows and columns for the 
matrix. It then calls the generate_matrix_char function 
to create a matrix with random character values. Finally, 
it prints the generated matrix.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-28"
-------------------------------------------------------
"""
# Imports
from functions import generate_matrix_char

# Input for rows and cols
rows = int(input("Number of rows: "))
cols = int(input("Number of columns: "))

# Calls on the functions generate_matrix_char
matrix = generate_matrix_char(rows, cols)

# Display the result
print(matrix)
