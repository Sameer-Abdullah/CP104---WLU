"""
-------------------------------------------------------
[This program demonstrates the use of the matrix_scalar_multiply 
function from the functions module.The program prompts 
the user to enter a number to multiply by and initializes 
a matrix. It then calls the matrix_scalar_multiply function 
to update the matrix by multiplying each element by the 
specified number.Finally, it prints the resulting matrix.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-28"
-------------------------------------------------------
"""
# Imports
from functions import matrix_scalar_multiply

# input for the num and matrix
num = float(input("Enter a number to multiply by: "))
matrix = [[-6, -3, -7], [-4, 5, -10]]

# Calls on the function matrix_scalar_multiply
matrix_scalar_multiply(matrix, num)

# output
print(matrix)
