"""
-------------------------------------------------------
[This program takes a date in the format YYYYMMDD,
and converts in to year, month, day]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-18"
-------------------------------------------------------
"""
# Imports
from functions import extract_date

# This is the input for the date_number
date_number = int(input("A date number in the format YYYYMMDD: "))

# Uses the function extract_date to convert year,month and day
year, month, day = extract_date(date_number)

# Output
print(f"{year}, {month}, {day}")
