"""
-------------------------------------------------------
[This program calculates the distance an object falls 
in a time inputed by the user.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-18"
-------------------------------------------------------
"""
# Imports
from functions import falling_distance

# This is the input for time the object fell down
falling_time = int(input("Enter the time the object fell in(s): "))

# This uses the function falling_distance to calculate the distance
distance = falling_distance(falling_time)

# Output
print(f"{distance:0.2f}")
