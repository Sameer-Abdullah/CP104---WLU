"""
-------------------------------------------------------
[This program calculates the time required to mow a 
lawn based on an input for the width, length and 
the speed of the mower.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-18"
-------------------------------------------------------
"""
# Imports
from functions import lawn_mow_time

# This is the input for the width, length of the lawn and speed of the lawn mower
width = float(input("Enter the width of the lawn: "))
length = float(input("Enter the length of the lawn: "))
speed = float(input("Enter the speed of the mower: "))

# Uses the function lawn_mow_time to calculate the time required to mow
time = lawn_mow_time(width, length, speed)

# Output
print(f"{time:0.2f}")
