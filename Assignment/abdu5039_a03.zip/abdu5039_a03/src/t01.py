"""
-------------------------------------------------------
[This program uses the variable square_feet to take an
input in square feet and converts it to a acres.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-18"
-------------------------------------------------------
"""
# Imports
from functions import footage_to_acres

# This is the input for the square feet
square_feet = float(input("Enter the square feet: "))

# Uses the function footage_to_acres to convert from feet to acres
acres = footage_to_acres(square_feet)

# Output
print(acres)
