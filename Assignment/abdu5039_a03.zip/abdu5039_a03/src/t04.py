"""
-------------------------------------------------------
[This program takes input for the denominator and 
numerator of a fraction and outputs the result]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-18"
-------------------------------------------------------
"""
# Imports
from functions import multiply_fractions

# This is the input for the num1, num2, den1, den2 of the fraction
num1 = int(input("Numerator of first fraction: "))
den1 = int(input("Denominator of first fraction: "))
num2 = int(input("Numerator of second fraction: "))
den2 = int(input("Denominator of second fraction: "))

# Uses the function multiply_fractions to multiply the two fractions
num, den, product = multiply_fractions(num1, den1, num2, den2)

# Output
print(f"{num}, {den}, {product}")
