"""
-------------------------------------------------------
[This program will determine even division with the modulus 
(%) operator. The modulus operator returns the remainder 
of an integer division]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import factor_summation

# This is the input
number = int(input("Enter a positive integer: "))

# calls on the function factor_summation
total = factor_summation(number)

# Output
print(total)
