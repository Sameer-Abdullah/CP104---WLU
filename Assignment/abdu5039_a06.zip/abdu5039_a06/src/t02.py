"""
-------------------------------------------------------
[This program checks if a number entered by the user is 
a pirme number]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import detect_prime

# This is the input
number = int(input("An integer: "))

# Calls on the function detect_prime
prime = detect_prime(number)

# Output
print(prime)
