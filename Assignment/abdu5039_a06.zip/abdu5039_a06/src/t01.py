"""
-------------------------------------------------------
[Uses a while loop to ask the user a input for the winning
team, it then tells the user how many times they guessed
purple and how many times they guessed gold.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import total_wins

# calls on the function total_wins
purple_count, gold_count = total_wins()

# Output
print(f"({purple_count},{gold_count})")
