"""
-------------------------------------------------------
[functions.py]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports

# t01.py


def total_wins():
    """
    -------------------------------------------------------
    total_wins takes no parameters and asks the user to enter
    a series of strings that represent the output of a game 
    with a loop. 
    Use: gold_count, purple_count = total_wins()
    -------------------------------------------------------
    Parameters:
        user_input - asks the user for an input (str)
    Returns:
        gold_count - keeps count of the number of gold entered (int => 1)
        purple_count - keeps count of the number of purple entered(
        int => 1)
    ------------------------------------------------------
    """
    user_input = "anything"
    gold_count = 0
    purple_count = 0

    while user_input != "":
        user_input = input("Enter the winning team: ")
        if user_input == "gold":
            gold_count += 1
        elif user_input == "purple":
            purple_count += 1

    return gold_count, purple_count


# t02.py
def detect_prime(number):
    """
    -------------------------------------------------------
    Determines if number is a prime number.
    Use: prime = detect_prime(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        prime - True if number is prime, False otherwise (bool)
    -------------------------------------------------------
    """
    divisor = 2
    prime = True

    while divisor * divisor <= number:
        if number % divisor == 0:
            prime = False
            break
        divisor += 1

    return prime

# t03.py


def interest_table(principal_amount, interest_rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_table(principal_amount, interest_rate, payment)
    -------------------------------------------------------
    Parameters:
        principal_amount - original value of a loan (float > 0)
        interest_rate - yearly interest interest_rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """
   # Print loan details
#
    print("----------------------------------")
    print("Month Interest   Payment   Balance")
    print("----------------------------------")

    # Initialize variables
    month = 1
    balance = principal_amount

    while balance > 0:
        interest = balance * (interest_rate / 100 / 12)
        balance = balance - payment + interest
        if balance < 0:
            payment = payment + balance
            balance = 0
        # Print monthly details
        print(
            f"    {month}     {interest:.2f}     {payment:.2f}     {balance:.2f}")
        month += 1

    return None

# t04.py


def count_of_digits(number):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: digits = count_of_digits(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int)
    Returns:
        digits - the number of digits in number (int)
    -------------------------------------------------------
    """

 # Initialize count to 0
    count = 0

    # Count digits using repeated division by 10
    while number > 0:
        number //= 10
        count += 1

    return count

# t05.py


def factor_summation(number):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = factor_summation(number)
    -------------------------------------------------------
    Parameters:
        number - a positive integer (int >= 1)
    Returns:
        total - the total of number's factors (int)
    ------------------------------------------------------
    """

    total = 0

    # Find factors using repeated division
    potential_factor = 1
    while potential_factor <= number // 2:
        if number % potential_factor == 0:
            total += potential_factor

        potential_factor += 1

    return total
