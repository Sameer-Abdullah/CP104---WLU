"""
-------------------------------------------------------
[This program will return how many digits are in a number 
entered by the user.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import count_of_digits

# This is the input
number = int(input("Enter a number: "))

# Calls on the function count_of_digital
digits = count_of_digits(number)

# Output
print(digits)
