"""
-------------------------------------------------------
[This program asks the user princple amount, interest rate
and the amount of payments, it tells the user how many 
months it will take and how much interest they are charged
each month.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import interest_table

# This is the input
principal_amount = float(input("Principal: $"))
interest_rate = float(input("Interest Rate: "))
payment = float(input("Monthly Payment: $"))

# Calls on the function interest_table
interest_table(principal_amount, interest_rate, payment)
