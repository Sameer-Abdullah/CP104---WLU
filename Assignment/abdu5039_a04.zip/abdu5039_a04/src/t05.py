"""
-------------------------------------------------------
[This program will ask the user for a number if the 
number is divisible by 2 it will return hoo, if the 
number is divisible by 7 then it will return Rah, if
the number is divisible by 2 and 7 it will return Hoo Rah
and if its none of the above it would be Zip]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import hoo_rah

# Input for the number
number = int(input("Enter a number to check with strigs: "))

# This will call on the function Hoo_Rah
result = hoo_rah(number)

# Output
print(result)
