"""
-------------------------------------------------------
[This program will ask the user to enter a number from
1 to 7 and depending on what number the user enters
the program will return the coorponding day. Ex 1 - sunday
2 - Monday and so on.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import day_name

# Input for the number to return what day it is
day_num = int(input("Enter a number from 1-7 to get the day: "))

# calls on the function day_num
day = day_name(day_num)

# Output
print(day)
