"""
-------------------------------------------------------
[This program will ask the user for two rgb colours, 
then tell them what colour the two colours would make
if mixed.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import colour_combine

# Input for rgb_colour1 and rgb_colour2
rgb_colour1 = str(input("Enter a rgb colour: "))
rgb_colour2 = str(input("Enter a secound rgb colour: "))

# This will call the function colour_combine
rgb_colour = colour_combine(rgb_colour1, rgb_colour2)

# Output
print(rgb_colour)
