"""
-------------------------------------------------------
[This program will ask the user for three numbers then
add the two highest of them. ]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import largest_average

# Input for Val1, Val2 and Val3
val1 = float(input("Enter the first number: "))
val2 = float(input("Enter the second number: "))
val3 = float(input("Enter the third number: "))

# This will call on the function largest_average
average = largest_average(val1, val2, val3)

# Output
print(average)
