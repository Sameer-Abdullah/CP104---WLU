"""
-------------------------------------------------------
[This program will check the air quality based on the 
input of the user, ex. 0-50 AQI is good... and so on]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import pollution_ranking

# Input for the AQI
air_quality_index = int(input("Air Quality Index: "))

# calls the function pollution_ranking
pollution = pollution_ranking(air_quality_index)

# Output
print(pollution)
