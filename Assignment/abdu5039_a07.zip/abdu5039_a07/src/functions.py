"""
-------------------------------------------------------
[functions.py for assignment 7, CP104]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
# Imports

# Function for t01.py


def list_factors(number):
    """
    -------------------------------------------------------
    This function will return the factos of a given number
    by the user. 
    Use: factors = list_factors(number)
    -------------------------------------------------------
    Parameters:
        number - this is the number entered by the user (int)
    Returns:
        factors - these are all the facros of the given number (int)
    ------------------------------------------------------
    """
    # This is an empty list
    factors = []

    # For look with ranger from 1 to number ( entered by the user)
    for i in range(1, number):
        # If condition checking if the entered number is divisible by 2
        if number % i == 0:
            # Adds the number to the new list if it is divisible by 2
            factors.append(i)
    # This will return factors
    return factors

# Function for t02.py


def list_positives():
    """
    -------------------------------------------------------
    Gets a list of positive numbers from a user.
    Negative numbers are ignored. Enter 0 to stop entries.
    Use: number_list = list_positives()
    -------------------------------------------------------
    Returns:
        number_list - A list of positive integers (list of int)
    ------------------------------------------------------
    """
    # This is a empty list
    number_list = []

    # Initlzing user_input
    user_input = 1

    # Creating a while loop with the condition that if the user_input == 0 exit the loop
    while user_input != 0:
        # This is the input for user_input
        user_input = int(input("Enter a positive number: "))
        # If statment checking if user_input is greater then or at least 1
        if user_input >= 1:
            # This will add user_input to the new list
            number_list.append(user_input)
    # This will return number_list
    return number_list

# Function for t03.py


def get_indexes(numbers, target_number):
    """
    -------------------------------------------------------
    Finds the indexes of target_number in numbers.
    Use: index_list = get_indexes(numbers, target_number)
    -------------------------------------------------------
    Parameters:
        numbers - list of values (list)
        target_number - value to look for in num_list (*)
    Returns:
        index_list - list of indexes of target_number (list of int)
    -------------------------------------------------------
    """
    # This is an empty list
    index_list = []

    # This is a for loop with the range of the length of the list created by the user
    for i in range(len(numbers)):
        # If statment checking if the target_number entered by the user matched the number in the list
        if target_number == numbers[i]:
            # Adds that number from that list to the new list
            index_list.append(i)
    # This will return index_list
    return index_list


# Function for t04.py
def list_subtract(minuend, subtrahend):
    """
    -------------------------------------------------------
    Alters the contents of minuend so that it does not contain
    any values in subtrahend.
    i.e. the values in the first list that appear in the second list
    are removed from the first list.
    Use: list_subtract(minuend, subtrahend)
    -------------------------------------------------------
    Parameters:
        minuend - a list of values (list)
        subtrahend - a list of values to not include in difference (list)
    Returns:
        None
    ------------------------------------------------------
    """
    result = [x for x in minuend if x not in subtrahend]
    minuend.clear()  # Clear the original minuend list
    minuend.extend(result)  # Update the minuend list with the result
    return None

# Function for t05.py


def verify_sorted(numbers):
    """
    -------------------------------------------------------
    Determines whether a list is sorted.
    Use: in_order, index = verify_sorted(numbers)
    -------------------------------------------------------
    Parameters:
        numbers - a list of numbers (list)
    Returns:
        in_order - True if numbers is sorted, False otherwise (bool)
        index - index of first value not in order,
            -1 if in_order is True (int)
    ------------------------------------------------------
    """
    # Intilizes in_order variable
    in_order = True
    # Initilizes the index variable
    index = -1
    # This is a for loop with the range being the length of the loop entered by the user minus one
    for i in range(len(numbers) - 1):
        # This is a if statment checking if values in the numbers list in position [i] is greater then numbers [i + 1]
        if numbers[i] > numbers[i + 1]:
            # Makes the variable in_order = to false
            in_order = False
            index = i + 1  # Index of the first value not in order
            # Exits the loop
            break
    # Returns in_order and index
    return in_order, index
