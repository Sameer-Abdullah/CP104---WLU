"""
-------------------------------------------------------
[This program will ask the user for list of numbers, 
negative and positive then return only the positive 
numbers. ]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
# Imports
from functions import list_positives

# This will call on the function list_positives
number_list = list_positives()

# Output
print(number_list)
