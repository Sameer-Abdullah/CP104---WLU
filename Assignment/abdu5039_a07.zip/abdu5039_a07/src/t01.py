"""
-------------------------------------------------------
[This program will ask the user to enter a number, then
it will check for all the factors of that number.  ]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
# Imports
from functions import list_factors

# This is the input fpr the number to check for the factor of
number = int(input("Enter a number to check for the factor: "))

# This will call on the function list_factors with the parameter number
factors = list_factors(number)

# Output
print(factors)
