"""
-------------------------------------------------------
[This program asks the user to enter a list then another 
value, it will then look for that value in the list and 
return all the positions the value is in. ]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
# Imports
from functions import get_indexes

# This is the input for the number of list and a value to look for within that list
number_list = input("Enter a list of values separated by spaces: ")
numbers = [int(val) for val in number_list.split()]
target_number = int(input("Enter a value to look for: "))

# This will call on the function get_indexes
index_list = get_indexes(numbers, target_number)

# Output
print(index_list)
