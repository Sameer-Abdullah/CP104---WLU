"""
-------------------------------------------------------
[This program will ask the user for a list then sort the
list and verify it.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
# Imports
from functions import verify_sorted

# This is the input for the list
numbers_list = input("Enter a list of values separated by spaces: ")
numbers = [int(val) for val in numbers_list.split()]

# This will call on the function verify_sorted
in_order, index = verify_sorted(numbers)

# Output
print(in_order, index)
