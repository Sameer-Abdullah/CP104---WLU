"""
-------------------------------------------------------
[This program will ask the user for 2 lists one minuend 
and one subtrahend, it will take away all the values of
the subtrahend numbers of the minuend.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-16"
-------------------------------------------------------
"""
# Imports
from functions import list_subtract

# This will ask the user for the input of a list
minuend_list = input("Enter a list of values separated by spaces:  ")
minuend = [int(val) for val in minuend_list.split()]

# This is also a list inputed by the user however, the values of this list will not be in the new list
subtrahend_list = input(
    "Enter a list of values separated by spaces to not include in the list: ")
subtrahend = [int(val) for val in subtrahend_list.split()]

# This will call on the function list_subtract with the parameters minurnd and subtrahend
list_subtract(minuend, subtrahend)

# Output
print(minuend)
