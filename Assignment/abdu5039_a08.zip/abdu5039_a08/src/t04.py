"""
-------------------------------------------------------
[This program will tell you if a ISBN is valid or not]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
# Imports
from functions import valid_isbn

# Take user input for the ISBN
isbn = input("Enter an ISBN: ")

# Test the function
is_valid = valid_isbn(isbn)

# Display the result
print(f"valid_isbn('{isbn}') -> {is_valid}")
