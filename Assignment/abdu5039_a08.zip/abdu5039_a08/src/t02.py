"""
-------------------------------------------------------
[This program asks the user for a input and stores it in
the variable string, then it will pluralize that string
and return it back to the user.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
# Imports
from functions import pluralize

# Take user input for the string
string = input("Enter a word to pluralize: ")

# Test the function
pluralized_word = pluralize(string)

# Display the result
print(f"{string} -> {pluralized_word}")
