"""
-------------------------------------------------------
[This Python program utilizes the 'has_word_chain' function 
from the 'functions' module. The program prompts the user to 
enter a list of words separated by spaces, and then it tests 
whether the provided list of words forms a word chain using the 
'has_word_chain' function. A word chain is defined as a list of 
words in which the last character of a word is the same as the 
first character of the next word.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
# Imports
from functions import has_word_chain

# Take user input for the words variable
words = input("Enter a list of words separated by spaces: ").split()

# Test the function
word_chain = has_word_chain(words)

# Display the result
print(f"has_word_chain({words}) -> {word_chain}")
