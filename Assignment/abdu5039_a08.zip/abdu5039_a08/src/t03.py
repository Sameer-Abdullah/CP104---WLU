"""
-------------------------------------------------------
[This Python program utilizes the 'common_end' function 
from the 'functions' module. The purpose of the program 
is to prompt the user for two strings and then test whether 
there is a common suffix between the two strings using the 
'common_end' function. The 'common_end' function returns 
the longest common ending of two strings.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
# Imports
from functions import common_end

# Take user input for str1 and str2
str1 = input("Enter the first string: ")
str2 = input("Enter the second string: ")

# Test the function
suffix = common_end(str1, str2)

# Display the result
print(f"common_end('{str1}', '{str2}') -> {suffix}")
