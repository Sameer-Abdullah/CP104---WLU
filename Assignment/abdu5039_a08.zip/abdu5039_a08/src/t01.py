"""
-------------------------------------------------------
[This Python program utilizes the 'add_spaces' function 
from the 'functions' module. The purpose of the program 
is to prompt the user for a sentence, and then it applies 
the 'add_spaces' function to transform the input sentence. 
The 'add_spaces' function takes a sentence in which all 
the words are run together (no spaces), but the first 
character of each word is uppercase. It returns a new 
sentence in which the words are separated by spaces, 
and only the first word starts with an uppercase character.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
# Imports
from functions import add_spaces

# Take user input for the sentence
sentence = input("Enter a sentence: ")

# Test the function
result = add_spaces(sentence)

# Display the result
print(result)
