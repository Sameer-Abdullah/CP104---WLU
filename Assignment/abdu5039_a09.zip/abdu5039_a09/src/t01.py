"""
-------------------------------------------------------
[This Python script uses the file_top function to print 
a user-specified number of lines from the file "student.txt." 
It demonstrates basic file handling and user input interaction. 
Note: There is a small issue in attempting to print the 
file handle after it has been closed.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
# Imports
from functions import file_top

# Get the file path from the user
file_path = "student.txt"

# Get the number of lines to print
count = int(input("Number of lines to print: "))

# Test the file_top function
with open(file_path, 'r', encoding="utf-8") as file_handle:
    file_top(file_handle, count)
print(file_handle, count)
