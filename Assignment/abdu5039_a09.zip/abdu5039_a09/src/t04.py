"""
-------------------------------------------------------
[This Python script tests the line_numbering function 
from the functions module. It reads the content of the 
file "wilde.txt," adds line numbers to each line, and 
writes the numbered content to a new file named 
"wilde_numbered.txt." The script demonstrates the 
functionality of the line_numbering function for the 
specified input file.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
# Imports
from functions import line_numbering

# Test the line_numbering function
read_file_path = "wilde.txt"
write_file_path = "wilde_numbered.txt"

with open(read_file_path, 'r', encoding="utf-8") as fh_read, \
        open(write_file_path, 'w', encoding="utf-8") as fh_write:
    line_numbering(fh_read, fh_write)
