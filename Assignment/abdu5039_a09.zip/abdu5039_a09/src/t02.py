"""
-------------------------------------------------------
[This Python script tests the read_integers function 
from the functions module. It prompts the user for a 
file path, reads the file, and prints the extracted 
positive integers. The script is concise and serves 
as a quick validation of the read_integers function.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
# Imports

from functions import read_integers

# Test the read_integers function
# Replace with the actual path to your test file
file_path = input("Enter a file to read: ")

with open(file_path, 'r', encoding="utf-8") as file_handle:
    numbers = read_integers(file_handle)

print(numbers)
