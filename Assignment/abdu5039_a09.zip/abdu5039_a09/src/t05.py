"""
-------------------------------------------------------
[This script tests the student_stats function from the 
functions module using the file "students.txt." It prints 
the lowest and highest mark IDs, along with the average 
mark. The script is concise, offering a quick demonstration 
of the student_stats function.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
# Imports
from functions import student_stats

# Test the student_stats function
file_path = "students.txt"  # Replace with the actual path to your test file

with open(file_path, 'r', encoding="utf-8") as file_handle:
    l_id, h_id, avg = student_stats(file_handle)

print(f"Lowest Mark ID: {l_id}")
print(f"Highest Mark ID: {h_id}")
print(f"Average Mark: {avg}")
