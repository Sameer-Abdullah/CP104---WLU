"""
-------------------------------------------------------
[This Python script tests the file_statistics function 
from the functions module on the file "addresses.txt." 
It prints the counts of uppercase letters, lowercase 
letters, digits, whitespace characters, and remaining 
characters. The script is concise, offering a swift 
validation of the file_statistics function.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
# Imports

from functions import file_statistics

# Test the file_statistics function
file_path = "addresses.txt"
with open(file_path, 'r', encoding="utf-8") as file_handle:
    ucount, lcount, dcount, wcount, rcount = file_statistics(file_handle)

print(f"Uppercase letters: {ucount}")
print(f"Lowercase letters: {lcount}")
print(f"Digits: {dcount}")
print(f"Whitespace characters: {wcount}")
print(f"Remaining characters: {rcount}")
