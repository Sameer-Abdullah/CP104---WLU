"""
-------------------------------------------------------
[This program will calculate the total tax on a sales 
amount entered by the user.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-05"
-------------------------------------------------------
"""

# Input for the total sales
total_sales = float(input("Enter the total sales: $"))

# User interface
print("\nProjected Tax Report\n------------------------")

# this is a variable constant for the tax
ANNUAL_TAX = 0.185

# This will calculate the total tax
tax = total_sales * ANNUAL_TAX

# These set of inputs will
print(f"Total sales:  ${total_sales:,.2f}")
print(f"Annual tax:   %{ANNUAL_TAX * 100:.2f}\n------------------------")
print(f"Tax:          ${tax:,.2f}")
