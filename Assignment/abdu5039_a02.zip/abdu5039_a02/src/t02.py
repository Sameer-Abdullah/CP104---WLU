"""
-------------------------------------------------------
[This program will direct the user to enter two numbers
then find the difference between the two numbers by
subtracting them from one another. Ex. 26 = 2-6 
                                          = -4]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-05"
-------------------------------------------------------
"""
# This is the input for the a two digit positive number
positive_digit = int(input("Enter a positive digit number: "))

# This will find the number in the tens and the number in the ones place
digit_tens_place = positive_digit // 10
digit_ones_place = positive_digit % 10

# This will subtract the number in the tens place from the number in the ones place to get the difference
difference = digit_tens_place - digit_ones_place

# This will output all the information
print(
    f"The difference of the digits of {positive_digit: d} is {difference: d}")
