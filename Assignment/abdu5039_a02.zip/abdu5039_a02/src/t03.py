"""
-------------------------------------------------------
[This program will ask the user for a date in the format
YYYYMMDD, then write the date in a reformed date of 
YYYY/ MM / DD]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-05"
-------------------------------------------------------
"""
# This will ask for an input for the date
date = int(input("Enter a date in the format YYYYMMDD: "))\

# these variables will calculate the day, month and year
day = date % 100
month = (date // 100) % 100
year = date // 10000

# This is the output for the reformed date
print(f"The reformatted date: {year:d}/{month:d}/{day:d}")
