"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-10-05"
-------------------------------------------------------
"""
# this is the output for the foundation length, width, height, the wall height, cost of concrete and the cost of bricks
foundation_length = float(input("Foundation length (m): "))
foundation_width = float(input("Foundation width (m): "))
foundation_height = float(input("Foundation height (m):"))
wall_height = float(input("Wall height (m): "))
cost_concrete = float(input("Cost of concrete ($/m^3): "))
cost_bricks = float(input("Cost of bricks ($/m^2): "))

# This will find the amount of concrete needed for the foundation
concrete_foundation = foundation_length * foundation_width * foundation_height

# This will calculate the cost of concrete
total_cost_concrete = concrete_foundation * cost_concrete

# This will figure out how much brick is needed for the walls
brick_area = (foundation_length + foundation_width) * 2 * (wall_height)

# This will find the actual cost of the bricks taking in to account the area the bricks need to cover
actual_cost_brick = brick_area * cost_bricks

# This will find the final and total cost for everything
total_cost = total_cost_concrete + actual_cost_brick

# these are the outputs for the foundation needed, cost of concrete,brick needed for the walls, cost of the bricks and the Grand total
print(f"\nConcrete needed for foundation (m^3): {concrete_foundation:.2f}")
print(f"Cost of concrete: ${total_cost_concrete:,.2f}")
print(f"Bricks needed for walls (m^2): {brick_area:0.2f}")
print(f"Cost of bricks: ${actual_cost_brick:,.2f}")
print(f"Total cost: ${total_cost:,.2f}")
