"""
-------------------------------------------------------
[This program will use the equation A = p(1+r/n)**nt to 
figure out compound interest.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Input for the principle amount, interest,number of years and compounding period
principle = float(input("Principal: "))
interest = float(input("Interest (%): "))
num_of_years = int(input("Number of years: "))
compound_period_yearly = int(
    input("Number of times interest compunded per year: "))

# calculating the interest as a decimal
decimal_interest = interest/100

# calculting the compound interest
compound_interest = principle * (
    1 + decimal_interest/compound_period_yearly)**(num_of_years * compound_period_yearly)

# Output for the total Balance
print(f"Balance: ${compound_interest:f}")
