"""
-------------------------------------------------------
[This program will ask the user for the cost/dosa and 
the number of dosas then give them the total cost.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Input for the number and cost of dosas
cost_dosa = float(input("Cost of 1 dosa: $"))
number_dosas = int(input("Number of dosa: "))

# Total cost for the dosa's
total_cost = number_dosas * cost_dosa

# output for total cost
print(f"Total cost of 3 dosas: ${total_cost:0.2f}")
