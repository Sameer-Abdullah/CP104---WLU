"""
-------------------------------------------------------
[This program will ask the user for their age and 
favourite band and print out the sentence bellow.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Inputs for age and favourite band
age = int(input("What is your age? "))
fav_band = input("What is your favourite band? ")

# Outputting the age and favourire band
print(f"I am {age} years old and {fav_band:s} is my favourite band.")
