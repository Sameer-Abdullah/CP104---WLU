"""
-------------------------------------------------------
[this program will convert a length entered by the user
in miles to kilometers.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-09-28"
-------------------------------------------------------
"""
# Input for length in miles
length_miles = float(input("Length in miles: "))

# calculating the length in kilometers
length_km = length_miles * 1.61

# Output for the length
print(f"Length in km: {length_km:0.2f}")
