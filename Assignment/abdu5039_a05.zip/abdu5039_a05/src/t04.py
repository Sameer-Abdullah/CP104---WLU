"""
-------------------------------------------------------
[This program generates and displays a multiplication 
table for a given range of values.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import multiplication_table

# Input: Get the start and stop numbers for the multiplication table from the user
start_num = int(input("Enter the start number: "))
stop_num = int(input("Enter the stop number: "))

# Generate the multiplication table using the multiplication_table function
table = multiplication_table(start_num, stop_num)

# Output: Display the generated multiplication table
print(table)
