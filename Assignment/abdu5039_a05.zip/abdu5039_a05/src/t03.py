"""
-------------------------------------------------------
[This program generates and displays an arrow made of 
'#' characters pointing upwards.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import arrow_up

# Input: Get the number of rows for the arrow from the user
rows = int(input("Enter the number of rows: "))

# Generate the arrow using the arrow_up function
arrow_up(rows)
