"""
-------------------------------------------------------
[functions.py]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports


def calc_factorial(number):
    """
    -------------------------------------------------------
    Calculates and returns the factorial of number.
    Use: product = calc_factorial(number)
    -------------------------------------------------------
    Parameters:
        number - number to factorial (int > 0)
    Returns:
        product - number! (int)
    ------------------------------------------------------
    """
    product = 1  # Initialize the product to 1, as the factorial of 0 is defined as 1.

    for i in range(1, number + 1):
        # Multiply product by numbers from 1 to 'number' to calculate the factorial.
        product *= i

    return product  # Return the calculated factorial.


def calories_treadmill(per_min, minutes):
    """
    -------------------------------------------------------
    Calculates and prints the calories burned on a treadmill.
    Use: calories = calories_treadmill(per_min, minutes)
    -------------------------------------------------------
    Parameters:
        per_min - (float) - Calories burned per minute.
        minutes - (int) - Total minutes of exercise.
    Returns:
         NONE
    ------------------------------------------------------
    """
    total_calories = 0.0  # Initialize the total calories burned to 0.0

    # Iterate in 5-minute intervals and calculate calories burned for each interval.
    for i in range(5, minutes + 1, 5):
        calories = i * per_min
        total_calories += calories  # Update the total calories burned
        print(f"{i:d} minutes -> {calories:.1f} calories")

    return None


def arrow_up(rows):
    """
    -------------------------------------------------------
    Generates a simple arrow pointing upwards made of '#' 
    characters.
    Use: arrow = arrow_up(rows)
    -------------------------------------------------------
    Parameters:
        rows (int) - Number of rows in the arrow.
    Returns:
        NONE
    ------------------------------------------------------
    """
    arrow = ""
    for i in range(1, rows + 1):
        spaces = " " * (rows - i)  # Calculate leading spaces for alignment.
        if i == 1:
            arrow += spaces + "#" + "\n"  # Add the top row of the arrow.
        else:
            inner_spaces = " " * ((i - 1) * 2 - 1)  # Calculate inner spaces.
            # Add a row with inner spaces.
            arrow += spaces + "#" + inner_spaces + "#" + "\n"
    print(arrow)

    return None


def multiplication_table(start_num, stop_num):
    """
    -------------------------------------------------------
    Prints a multiplication table for values from start_num to stop_num.
    Use: multiplication_table(start_num, stop_num)
    -------------------------------------------------------
    Parameters:
        start_num - the range start value (int)
        stop_num - the range stop value (int)
    Returns:
        None
    ------------------------------------------------------
    """
    # Print the header row with column labels
    print(" " * 6, end="")  # Indentation for column alignment
    for i in range(start_num, stop_num + 1):
        print(f"{i:6}", end="")  # Format each column label with 6 characters
    print("\n" + " " * 6 + "-" * 19)  # Separator line for the header

    # Print the multiplication table
    for i in range(start_num, stop_num + 1):
        print(f"{i:2} |", end="")  # Left-align and label each row
        for j in range(start_num, stop_num + 1):
            result = i * j
            print(f"{result:6}", end="")  # Format each cell with 6 characters
        print()

    return None


def range_addition(start, increment, count):
    """
    -------------------------------------------------------
    Uses a for loop to sum values from start by increment.
    Use: total = range_addition(start, increment, count)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """
    # Initialize the total sum to 0
    total = 0

    # Loop 'count' times to accumulate values
    for i in range(count):
        total += start  # Add the current 'start' value to the total
        start += increment  # Increment 'start' by the specified 'increment' value

    # Return the final total sum
    return total
