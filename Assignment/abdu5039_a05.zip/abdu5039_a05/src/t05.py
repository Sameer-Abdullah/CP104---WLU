"""
-------------------------------------------------------
[This program calculates the sum of values in a range 
with a specified start value and increment.]
-------------------------------------------------------
Author:  Sameer Abdullah
ID:          169065039
Email:     abdu5039@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import range_addition

# Input: Get the number of values, start value, and increment from the user
count = int(input("Enter the number of values in the range: "))
start = int(input("The start value: "))
increment = int(input("Enter the increment: "))

# Calculate the sum of values using the range_addition function
total = range_addition(start, increment, count)

# Output: Display the calculated total sum
print(total)
