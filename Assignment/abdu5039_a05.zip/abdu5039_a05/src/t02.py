"""
-------------------------------------------------------
[This program calculates the total calories burned 
on a treadmill.]
-------------------------------------------------------
Author:  Bisma Khan
ID:          169050037
Email:     khan0037@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import calories_treadmill

# Input: Get the calories burned per minute and the maximum number of minutes from the user
per_min = float(input("Enter the calories burned per minute: "))
minutes = int(input("Enter the maximum number of minutes: "))

# Calculate the total calories burned using the calories_treadmill function
total_calories = calories_treadmill(per_min, minutes)
