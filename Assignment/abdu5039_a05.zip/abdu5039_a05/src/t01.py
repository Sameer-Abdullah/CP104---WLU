"""
-------------------------------------------------------
[This program calculates the factorial of a given 
number and displays the result.]
-------------------------------------------------------
Author:  Bisma Khan
ID:          160050036
Email:     khan0037@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import calc_factorial

# Input: Get the number for which you want to calculate the factorial from the user
number = int(input("Enter a number to calculate its factorial: "))

# Calculate the factorial using the calc_factorial function
product = calc_factorial(number)

# Output: Display the calculated factorial
print(f"The factorial of {number} is {product}.")
